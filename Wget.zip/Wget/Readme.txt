These release has been compiled with ssl support. The required libraries 
(ssleay32.dll and libeay32.dll) need to be kept in the same directory as
wget.exe or in a system directory (c:\windows or c:\windows\system32 could
be a working choice).